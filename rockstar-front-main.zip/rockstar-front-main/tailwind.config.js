const plugin = require('tailwindcss/plugin');
const defaultTheme = require('tailwindcss/defaultTheme')

module.exports = {
  daisyui: {
    themes: [
      {
        cupcake: {
            ...require("daisyui/src/theming/themes")["cupcake"],
            'primary' : '#fff',
            'secondary' : 'rgb(96, 97, 97)',
            'accent'  : 'rgb(239, 72, 2)',
            'accent-content'  : '#fff',
            'secondary-content' : 'rgb(237, 77, 51)',
            'base-100': 'rgb(181, 160, 225)',
        },
      },
      {
        dark: {
            ...require("daisyui/src/theming/themes")["dark"],
            'secondary' : '#571400',
            'base-100': "#525252",
        },
      },
      "aqua",
    ],
    darkTheme: "cupcake", // name of one of the included themes for dark mode
    base: true, // applies background color and foreground color for root element by default
    styled: true, // include daisyUI colors and design decisions for all components
    utils: true, // adds responsive and modifier utility classes
    prefix: "", // prefix for daisyUI classnames (components, modifiers and responsive class names. Not colors)
    logs: true, // Shows info about daisyUI version and used config in the console when building your CSS
    themeRoot: ":root", // The element that receives theme color CSS variables
  },
  darkMode: "class",
  presets: [require("@medusajs/ui-preset")],
  content: [
    "./src/app/**/*.{js,ts,jsx,tsx}",
    "./src/pages/**/*.{js,ts,jsx,tsx}",
    "./src/components/**/*.{js,ts,jsx,tsx}",
    "./src/modules/**/*.{js,ts,jsx,tsx}",
    "./node_modules/@medusajs/ui/dist/**/*.{js,jsx,ts,tsx}",
  ],
  theme: {
    extend: {
      transitionProperty: {
        width: "width margin",
        height: "height",
        bg: "background-color",
        display: "display opacity",
        visibility: "visibility",
        padding: "padding-top padding-right padding-bottom padding-left",
      },
      colors: {
        theme: {
          0: "rgb(239, 80, 158)", //menu color
          1: "#f10979", //input focus/ categories button 
          2: "rgb(247, 167, 201)",
          3: "white", 
          4: "black", //categories button text
          
        },
        grey: {
          0: "#FFFFFF",
          5: "#F9FAFB",
          10: "#F3F4F6",
          20: "#E5E7EB",
          30: "#D1D5DB",
          40: "#9CA3AF",
          50: "#6B7280",
          60: "#4B5563",
          70: "#374151",
          80: "#1F2937",
          90: "#111827",
        },
      },
      borderRadius: {
        none: "0px",
        soft: "2px",
        base: "4px",
        rounded: "8px",
        large: "16px",
        circle: "9999px",
      },
      maxWidth: {
        "8xl": "100rem",
      },
      screens: {
        "2xsmall": "320px",
        xsmall: "512px",
        small: "1024px",
        medium: "1280px",
        large: "1440px",
        xlarge: "1680px",
        "2xlarge": "1920px",
      },
      fontSize: {
        "3xl": "2rem",
      },
      fontFamily: {
        futura: "Futura, sans-serif",...defaultTheme.fontFamily.sans,
        myriadPro: "MyriadPro, sans-serif",
        sans: [
          "Futura",
          "MyriadPro",
          "Helvetica Neue",
          "Ubuntu",
          "sans-serif",
        ],
      },
      fontWeight: {
        thin: '100',
        hairline: '100',
        extralight: '200',
        light: '300',
        normal: '400',
        medium: '500',
        semibold: '600',
        bold: '700',
        extrabold: '800',
        'extra-bold': '800',
        black: '900',
      },
      keyframes: {
        oscillate: {
          "0%": { transform: "rotate(-30deg)" },
          "50%": { transform: "rotate(30deg)" },
          "100%": { transform: "rotate(-30deg)" },
        },
        pingloop: {
          "0%": { transform: "scale(1)", opacity: 1 },
          "50%": { transform: "scale(1.5)", opacity: 0.3 },
          "100%": { transform: "scale(1)", opacity: 1 },
        },
        pingS: {
          "0%": { transform:  "translateX(0px)"},
          "50%": { transform: "translateX(10px)"},
          "100%": { transform: "translateX(0px)"},
        },
        popupMove: {
          "0%": { transform:  "translateX(0%)"},
          "80%": { transform:  "translateX(0%)"},
          "100%": { transform: "translateX(100%)"},
        },
        moveXline1: {
          "0%": { transform:  "translateX(-20%)"},
          "100%": { transform: "translateX(20%)"},
        },
        moveXline2: {
          "0%": { transform:  "translateX(-100%)"},
          "100%": { transform: "translateX(0%)"},
        },
        scaleUp: {
          "0%": { transform: "scale(1)" },
          "100%": { transform: "scale(1.1)" },
        },
        ring: {
          "0%": { transform: "rotate(0deg)" },
          "100%": { transform: "rotate(360deg)" },
        },
        "fade-in-right": {
          "0%": {
            opacity: "0",
            transform: "translateX(10px)",
          },
          "100%": {
            opacity: "1",
            transform: "translateX(0)",
          },
        },
        "fade-in-top": {
          "0%": {
            opacity: "0",
            transform: "translateY(-10px)",
          },
          "100%": {
            opacity: "1",
            transform: "translateY(0)",
          },
        },
        "fade-out-top": {
          "0%": {
            height: "100%",
          },
          "99%": {
            height: "0",
          },
          "100%": {
            visibility: "hidden",
          },
        },
        "accordion-slide-up": {
          "0%": {
            height: "var(--radix-accordion-content-height)",
            opacity: "1",
          },
          "100%": {
            height: "0",
            opacity: "0",
          },
        },
        "accordion-slide-down": {
          "0%": {
            "min-height": "0",
            "max-height": "0",
            opacity: "0",
          },
          "100%": {
            "min-height": "var(--radix-accordion-content-height)",
            "max-height": "none",
            opacity: "1",
          },
        },
        enter: {
          "0%": { transform: "scale(0.9)", opacity: 0 },
          "100%": { transform: "scale(1)", opacity: 1 },
        },
        leave: {
          "0%": { transform: "scale(1)", opacity: 1 },
          "100%": { transform: "scale(0.9)", opacity: 0 },
        },
        "slide-in": {
          "0%": { transform: "translateY(-100%)" },
          "100%": { transform: "translateY(0)" },
        },
      },
      animation: {
        ring: "ring 2.2s cubic-bezier(0.5, 0, 0.5, 1) infinite",
        "fade-in-right":
          "fade-in-right 0.3s cubic-bezier(0.5, 0, 0.5, 1) forwards",
        "fade-in-top": "fade-in-top 0.2s cubic-bezier(0.5, 0, 0.5, 1) forwards",
        "fade-out-top":
          "fade-out-top 0.2s cubic-bezier(0.5, 0, 0.5, 1) forwards",
        "accordion-open":
          "accordion-slide-down 300ms cubic-bezier(0.87, 0, 0.13, 1) forwards",
        "accordion-close":
          "accordion-slide-up 300ms cubic-bezier(0.87, 0, 0.13, 1) forwards",
        enter: "enter 200ms ease-out",
        "slide-in": "slide-in 1.2s cubic-bezier(.41,.73,.51,1.02)",
        'spin-slow': 'spin 10s linear infinite',
        'bounce-slow': 'bounce 10s ease infinite',
        'oscillate-slow': 'oscillate 10s ease infinite',
        'ping-slow': 'ping 10s linear',
        'ping-loop': 'pingloop 10s ease infinite',
        'pingS': 'pingS 2s linear infinite',
        'moveXline1': 'moveXline1 10s ease infinite',
        'moveXline2': 'moveXline2 5s linear infinite',
        'popupMove': 'popupMove 5s linear forwards',
        'pulse-slow': 'pulse 10s linear infinite',
        'scale-up': 'scaleUp 0.5s ease forwards',
        'scale-up-loop': 'scaleUp 1s infinite',
        leave: "leave 150ms ease-in forwards",
      },
    },
  },
  plugins: [
    require("tailwindcss-radix")(),
    require('daisyui'),
  
  ],
  
}
