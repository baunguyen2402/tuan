import { Metadata } from "next"
import Image from "next/image"
import Script from "next/script"
import Iframe from "react-iframe"
import React from "react";
import TabsComponent from "@modules/layout/components/tabs/TabsComponent"

export const metadata: Metadata = {
  title: "RockStar nailsnSpa - 1100 NJ-35 # 26, Ocean Township, NJ 07712",
  description: 
    "Happy Hour and more...",
}
export default async function About() {

    return (
    <>        

    <div className="w-full bg-base-100 grid gap-4 xsmall:gap-6 font-futura text-white font-thin text-sm">
      <div className="Banner w-full h-fit xl:h-[300px] object-bottom overflow-hidden mx-auto">
        <Image src="https://webnailsbucket.s3.amazonaws.com/pasch/about-banner.png" 
          alt="banner" 
          width={1440} 
          height={300} 
          sizes="100%"
          style={{
            width: '100%',
            height: 'auto',
          }}/>
      </div>
      
      <div className="w-full max-w-6xl min-h-screen mx-auto grid place-content-start gap-4 xsmall:gap-6">
        <h1 className="Services-title font-normal text-xl text-primary md:text-2xl uppercase mx-auto drop-shadow-xl">OUR COLLECTION</h1>
        <TabsComponent items={items} />
      </div>
    </div>
    
    </>
)}

const items = [
  {
    title: 'Description',
    content: (
      <>
        <Image className="xsmall:w-[35%] mx-auto mb-4 rounded-xl shadow-xl" 
        src="https://webnailsbucket.s3.amazonaws.com/rockstar/banner+about.jpg" 
        alt="banner" 
        width={365} 
        height={365} 
        />
        <div className="xsmall:w-[60%] space-y-4 text-justify">
          <p>
          Welcome to RockStar nailsnSpa. Where your comfort, safety & satisfaction are our top priority. We offer both the latest techniques and products in hopes of replicating that same experience of enlightenment and beauty while servicing you in a relaxing and comfortable atmosphere. Our professionally trained staff is dedicated to delivering exceptional value in assisting your nails into looking healthy, vibrant and beautiful. We provides a complete collection of therapeutic and refreshing nail care as well as waxing.                   
          </p>
          <p>
          Our goal is to simply give our client the ultimate experience in nail pampering, ensuring that they walk out feeling great! Our clients love RockStar nailsnSpa for the great level of hospitality, customer service and quality. We strive to do our best and welcome your comments and feedback. In keeping with our commitment to cleanliness and hygiene, we adhere to strict sanitation practices for the protection of your health. RockStar nailsnSpa appreciates your patronage!                    
          </p>
        </div>
      </>
      
    ),
  },
  {
    title: 'Location',
    content: (
      <>
      <div className="w-full">
        <div>
          <iframe 
            className="w-full rounded-lg mb-4"
            title="google map"
            src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d6110.839722522961!2d-74.0423647646787!3d40.23771474188933!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c229cbc840e0ad%3A0xb05457d1a65b18ab!2sRockStar%20Nails%20N%20Spa!5e0!3m2!1svi!2s!4v1719464836088!5m2!1svi!2s" 
            width="100%" 
            height="450"
            style={{ border: 0 }}
            allowFullScreen={false}
            aria-hidden="false"
            tabIndex={0}
            >
          </iframe>
          <a 
            title="social-link"
            href="https://maps.app.goo.gl/r51kvP9DjLQrUMmr5" 
            target="_blank"
            rel="noopener noreferrer"
            >
            <h1 className="text-center text-xl my-6 uppercase underline underline-offset-4"><strong>Direction</strong></h1>
          </a>
        </div>
        <div className="w-full xsmall:inline-flex items-start justify-center xsmall:space-x-10">
          <Image className="xsmall:w-[35%] rounded-xl mx-auto mb-4 shadow-xl" 
          src="https://webnailsbucket.s3.amazonaws.com/rockstar/banner+about.jpg" 
          alt="banner" 
          width={365} 
          height={365} 
          />
          <div className="xsmall:w-[60%] space-y-4 text-justify">
            <p>
            Your Ultimate Destination for Beauty in Ocean Township, NJ; RockStar nailsnSpa is the destination for all your nail care needs. Our goal is to provide customer service and satisfaction without compromising our professional integrity and the satisfaction of our customers. We are run by the most qualified and knowledgeable professionals dedicated to the art of nail care and beauty.                      
            </p>
            <p>
            All of our products used in treatments are from the top brands. We also use Dipping Powder from brands such as SNS &OPI. We are a clean salon with your safety as our first priority! We will always take pride in ourselves in offering you a relaxing and luxurious spa experience.
            </p>
          </div>    
        </div>
      </div>
      
      </>
    ),
  },
  {
    title: 'Experience',
    content: (
      <>
      <Image className="xsmall:w-[35%] mx-auto mb-4 shadow-xl" 
        src="https://webnailsbucket.s3.amazonaws.com/pasch/experience-banner.png" 
        alt="banner" 
        width={365} 
        height={365} 
        />
      <div className="xsmall:w-[60%] space-y-4 text-justify">
        <p>
        @ RockStar nailsnSpa – We offer: nail care services & waxing.  Our staff has undergone extensive training on safety procedure and healthy nail care.                      
        </p>
        <p>
        Do you have specific nail request? Bring us your inspiration and we’d love to work with you on everything from color to shape, pattern to polish, length to volume. If you want something special but aren’t exactly sure, our technician will consult with you to find the perfect nail to make your day come true.                      
        </p>
      </div>   
      </>
    ),
  },
  
];