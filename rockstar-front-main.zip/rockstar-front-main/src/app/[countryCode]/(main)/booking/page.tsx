import { Metadata } from "next"
import Image from "next/image"
import Script
 from "next/script"
export const metadata: Metadata = {
  title: "RockStar nailsnSpa - 1100 NJ-35 # 26, Ocean Township, NJ 07712",
  description:
    "Happy Hour and more...",
}

export default async function News() {
    return (
    <>
      <div className="w-full bg-base-100 grid gap-4 xsmall:gap-6 font-futura text-white">
        <div className="Banner w-full h-fit xl:h-[300px] overflow-hidden mx-auto">
          <Image src="https://webnailsbucket.s3.amazonaws.com/pasch/news-banner.png" 
          alt="banner" 
          width={1440} 
          height={300} 
          style={{
            width: '100%',
            height: 'auto',
          }}/>
        </div>
        <Script type="text/javascript" src="https://plugin.mysalononline.com/Scripts/external/bookingplugin.js"></Script>

        <div className="w-full max-w-6xl min-h-screen mx-auto grid place-content-start justify-center overflow-hidden md:gap-6">
            <h1 className="Services-title font-normal text-xl md:text-2xl uppercase drop-shadow-xl text-center">Booking</h1>
            <iframe 
              className="mb-4 bg-center bg-[length:50px_50px] bg-no-repeat mask mask-squircle"
              title="booking"
              src="https://plugin.mysalononline.com/External/BookingPlugin/?guid=e68869d2-43f4-4f58-a035-8d4a4cf2a5ce" 
              width="430px"
              height="460px"
              style={{ border: 0 }}
              allowFullScreen={false}
              aria-hidden="false"
              tabIndex={0} 
              >
            </iframe>
        </div>
      </div>
    </>
)}
