//import { Product } from "@medusajs/medusa"
import { Metadata } from "next"
import Image from "next/image"
import SocialLink from "@modules/layout/components/socialLink"

//weather widget get data
import { Location, HourlyForecastResponse } from "lib/weather-plugin/types"
import { getHourlyData } from "lib/weather-plugin/getHourlyData"
import CurrentWeather from "lib/weather-plugin/CurrentWeather"
import HourlyForecast from "lib/weather-plugin/HourlyForecast"
import { notFound } from "next/navigation"
import Booking_button from "@modules/layout/components/booking-button"
const DEFAULT_LOCATION: Location = {
  city: "Ocean Township, NJ, US",
  coord: {
    lat: "40.252",
    lon: "-74.046",
  },
}

const { lat, lon } = DEFAULT_LOCATION.coord


export const metadata: Metadata = {
  title: "RockStar nailsnSpa - 1100 NJ-35 # 26, Ocean Township, NJ 07712",
  description:
    "Happy Hour and more...",
}

export default async function Home() {
  //get weather data
  const HourlyDataRequest: HourlyForecastResponse = await getHourlyData({
    lat,
    lon,
  })

  const [hourly_data] =
      await Promise.all([
        HourlyDataRequest,
      ])
  if (!hourly_data) return notFound()

  return (
    <>
      <div className="max-w-6xl w-full h-screen -mb-12 sm:-mb-16 p-5 mx-auto items-end md:items-center overflow-hidden font-futura text-primary z-0">
        <div className="popup-poster hidden absolute top-0 left-0 w-[100vw] h-[100vh] flex-col bg-[rgba(62,93,171)] place-content-center items-center overflow-hidden animate-popupMove z-50">
          <div className="flex w-5/6 md:w-[400px] content-center">
            <Image
              src="https://webnailsbucket.s3.amazonaws.com/common/popup/4ofJuly-Rockstar.png"
              alt="popup"
              width={600} 
              height={600} 
              style={{
                width: "100%",
                height: "auto",
              }}
            />
          </div>
          
          <div className="inline-flex w-[1400px] h-60 items-center justify-evenly">
            <Image
              className="w-1/2 h-20 items-center animate-moveXline1"
              src="https://webnailsbucket.s3.amazonaws.com/common/popup/4ofJulytext.png"
              alt="popup"
              width={1400} 
              height={19} 
              style={{
                width: "100%",
                height: "auto",
              }}
            />
          </div>
        </div>
        <div className="hidden relative -top-10 w-full justify-center">
          <CurrentWeather data={hourly_data.list[0]} city={hourly_data.city} />
        </div>

        <div className="logocontent flex-col w-full md:w-3/5 h-1/3 xl:h-4/5 content-end xl:content-center mx-auto place-content-center z-30">

          <div className="Welcom w-full">
            <Image src="https://webnailsbucket.s3.amazonaws.com/rockstar/welcome.png" 
            alt="Icon" 
            width={755} 
            height={258}
            />
          </div>
          
          <div className="Book-button w-full xl:pt-10 z-20"> 
            <div className="desktop-button hidden xl:block w-full z-20">
              <a
                className='inline-flex w-full space-x-6 place-content-end'
                title="booking_link"
                href="/booking"
              >
                <Image
                  className='w-10 animate-pingS'
                  src="https://webnailsbucket.s3.amazonaws.com/rockstar/book+arrow.png"
                  alt="button"
                  width={63}
                  height={32}
                />
                <Image
                  className='w-64'
                  src="https://webnailsbucket.s3.amazonaws.com/rockstar/book+an.png"
                  alt="button"
                  width={362}
                  height={28}
                />
              </a>

              <div className="w-1/4 xl:w-[15vw] hidden xl:block absolute top-1/2 right-1/4 xl:left-[15vw] xl:top-[20vh]">
                <div className="mr-[30%] animate-bounce-slow z-20">
                  <Image src="https://webnailsbucket.s3.amazonaws.com/rockstar/picker.svg"
                    alt="image" 
                    width={182} 
                    height={236}
                    style={{
                      width: '100%',
                      height: 'auto',
                    }}/>
                </div>
                <div className="relative ml-[20%] animate-spin-slow hover:animate-spin z-10">
                  <Image src="https://webnailsbucket.s3.amazonaws.com/rockstar/rolling+bottle.svg"
                    alt="image" 
                    width={215} 
                    height={215}
                    style={{
                      width: '100%',
                      height: 'auto',
                    }}/>
                </div>
              </div>
              
            </div>
            

            <a
              className='mobile-button inline-flex xl:hidden place-content-start place-items-end z-20'
              title="booking_link"
              href="/booking"
            >
              <div
                className="z-10 inline-flex -mr-10 items-center space-x-4 absolute top-[65vh] right-[55vw] md:top-[65vh] md:left-[5vw] animate-pingS">
                <Image
                  className='w-48 md:w-72'
                  src="https://webnailsbucket.s3.amazonaws.com/rockstar/book+an.png"
                  alt="button"
                  width={362}
                  height={28}
                />
                <Image
                  className='w-10 md:w-16'
                  src="https://webnailsbucket.s3.amazonaws.com/rockstar/book+arrow.svg"
                  alt="button"
                  width={100}
                  height={50}
                />
              </div>
              
              <div className="z-0 w-32 md:w-48 absolute top-[45vh] right-[15vw] md:left-[40vw]">
                <div className="mr-[25%] animate-bounce-slow">
                  <Image src="https://webnailsbucket.s3.amazonaws.com/rockstar/picker.svg"
                    alt="image" 
                    width={182} 
                    height={236}
                    style={{
                      width: '100%',
                      height: 'auto',
                    }}/>
                </div>
                <div className="relative ml-[20%] animate-spin-slow hover:animate-ping z-10">
                  <Image src="https://webnailsbucket.s3.amazonaws.com/rockstar/rolling+bottle.svg"
                    alt="image" 
                    width={215} 
                    height={215}
                    style={{
                      width: '100%',
                      height: 'auto',
                    }}/>
                </div>
              </div>
            </a>
          </div>

        </div>

        <div className="widget sm:pb-12 md:inline-flex w-full h-2/3 xl:h-1/5 content-end items-end xl:items-center justify-between space-y-0 xsmall:space-y-0 z-10">
          <div className="left_widget w-full h-20 inline-flex items-center justify-center xsmall:justify-start md:w-[60%] xsmall:space-x-10">
            <div className="h-16">
              <CurrentWeather data={hourly_data.list[0]} city={hourly_data.city} />
            </div>
            <div className="social_widget hidden sm:inline-flex items-center justify-between xsmall:justify-start space-x-4">
              <SocialLink/>
            </div>
          </div>

          <div className="right_widget grid place-items-center font-josefinSlab text-sm md:place-items-end w-full xsmall:w-280px md:w-[450px] mx-auto xsmall:mx-0">
            <div className="md:mb-6 space-x-6 items-center">
              <p className="inline-flex">
                Hello, how can i help you?
              </p>
              <a 
                className="inline-flex underline text-xs"
                href="tel:+1(732) 918 8100"
                >
              Customer Services
              </a>
            </div>

            <iframe 
              className="rounded-lg md:-my-10 bg-transparent scale-75"
              title="radio_bar"
              src="https://webnailsbucket.s3.amazonaws.com/common/radio.html" 
              width="280" 
              height="100"
              style={{ border: 0, overflow: "hidden"}}
              allowFullScreen={false}
              aria-hidden="false"
              tabIndex={0}
              >
            </iframe>
          </div>
        </div>
        
      </div>

      
        
      <div className="w-full h-screen absolute top-0 overflow-hidden bg-base-100 -z-50">
        <div className="w-[20vw] xl:w-[10vw] absolute right-[15vw] xl:right-[25vw] top-0 animate-ping-loop z-40">
          <Image src="https://webnailsbucket.s3.amazonaws.com/rockstar/droplet.svg"
            alt="image" 
            width={153} 
            height={247}
            style={{
              width: '100%',
              height: 'auto',
            }}/>
        </div>
        <div className="below-flower w-[1024px] md:w-full absolute bottom-0 animate-pulse z-0">
          <Image src="https://webnailsbucket.s3.amazonaws.com/rockstar/below+flower+bg.svg"
            alt="image" 
            width={1435} 
            height={520}
            style={{
              width: '100%',
              height: 'auto',
            }}/>
        </div>
      </div>
        
    </>
  )
}
