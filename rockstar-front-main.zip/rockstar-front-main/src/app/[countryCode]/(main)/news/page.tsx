import { Metadata } from "next"
import Image from "next/image"


export const metadata: Metadata = {
  title: "RockStar nailsnSpa - 1100 NJ-35 # 26, Ocean Township, NJ 07712",
  description:
    "Happy Hour and more...",
}
export default async function News() {
    return (
    <>
      <div className="w-full bg-base-100 grid gap-4 xsmall:gap-6 font-futura text-base-content">
        <div className="Banner w-full h-fit xl:h-[300px] object-bottom overflow-hidden mx-auto">
          <Image src="https://webnailsbucket.s3.amazonaws.com/pasch/news-banner.png" 
          alt="banner" 
          width={1440} 
          height={300} 
          style={{
            width: '100%',
            height: 'auto',
          }}/>
        </div>

        <div className="w-full max-w-6xl min-h-screen mx-auto grid place-content-start gap-4 md:gap-6">
          <h1 className="Services-title font-normal text-xl text-primary md:text-2xl uppercase drop-shadow-xl">BLOGGER BEAUTY</h1>
      
          <h1 className="Services-title font-normal text-xl text-primary md:text-2xl uppercase drop-shadow-xl">NEWS AND INSPIRATION</h1>

        </div>
      
      </div>
    </>
)}
