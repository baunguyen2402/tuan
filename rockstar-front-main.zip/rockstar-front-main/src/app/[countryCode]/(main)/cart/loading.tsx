import SkeletonCartPage from "@modules/skeletons/templates/skeleton-cart-page"

export default function Loading() {
  return <SkeletonCartPage />
}
