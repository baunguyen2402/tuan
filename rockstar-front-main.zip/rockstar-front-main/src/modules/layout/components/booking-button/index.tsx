import Image from 'next/image'

const Booking_button = () => {
 
  return (
    <> 
      
      <a
        className='has-tooltip inline-flex space-x-4 md:space-x-6 place-content-start place-items-end'
        title="booking_link"
        href="/booking"
      >
        
        <Image
          className='w-8 md:w-14 animate-pingS -mr-6 mb-3 md:-mr-10 md:mb-4'
          src="https://webnailsbucket.s3.amazonaws.com/rockstar/bookbutton arrow.svg"
          alt="button"
          width={100}
          height={50}
        />
        <div className="w-24 md:w-36">
          <div className="mr-[20%] animate-bounce-slow z-50">
            <Image src="https://webnailsbucket.s3.amazonaws.com/rockstar/picker.svg"
              alt="image" 
              width={182} 
              height={236}
              style={{
                width: '100%',
                height: 'auto',
              }}/>
          </div>
          <div className="relative ml-[20%] animate-spin-slow z-10">
            <Image src="https://webnailsbucket.s3.amazonaws.com/rockstar/rolling+bottle.svg"
              alt="image" 
              width={215} 
              height={215}
              style={{
                width: '100%',
                height: 'auto',
              }}/>
          </div>
        </div>
        <span className='w-48 tooltip absolute -bottom-8 -right-2 rounded p-1 text-accent text-xs'>Book an appointment</span>
      </a>
    </>
  )
}
export default Booking_button