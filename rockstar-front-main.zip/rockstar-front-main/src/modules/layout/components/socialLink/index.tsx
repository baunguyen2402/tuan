const SocialLink = () => {
 
  return (
    <> 
    <a
      title="social-link"
      href="https://www.facebook.com/rockstarnailsnspa07712/"
      target="_blank"
      rel="noopener noreferrer"
      className="
      facebook_link
      bg-[url('https://webnailsbucket.s3.amazonaws.com/pasch/Icon+Logo-02.svg')] 
      hover:animate-ping
      bg-cover bg-no-repeat p-2 w-10 h-10"
    ></a>

    <a
      title="social-link"
      href="https://www.instagram.com/rockstar_nails_n_spa/"
      target="_blank"
      rel="noopener noreferrer"
      className="
      instagram_link
      bg-[url('https://webnailsbucket.s3.amazonaws.com/pasch/Icon+Logo-03.svg')] 
      hover:animate-ping
      bg-cover bg-no-repeat p-2 w-10 h-10"
    ></a>

    <a
      title="social-link"
      href="yelp.com/biz/rockstar-nails-n-spa-ocean-township"
      target="_blank"
      rel="noopener noreferrer"
      className="
      yelp_link
      bg-[url('https://webnailsbucket.s3.amazonaws.com/pasch/Icon+Logo-06.svg')] 
      hover:animate-ping
      bg-cover bg-no-repeat p-2 w-10 h-10"
    ></a>

    <a
      title="social-link"
      href="tel:(732) 918 8100"
      target="_blank"
      rel="noopener noreferrer"
      className="
      call_link
      bg-[url('https://webnailsbucket.s3.amazonaws.com/pasch/Icon+Logo-05.svg')] 
      hover:animate-ping
      bg-cover bg-no-repeat p-2 w-10 h-10"
    ></a>

    <a
      title="social-link"
      href="goo.gl/maps/efP2rn7xzhEvF2NK9"
      target="_blank"
      rel="noopener noreferrer"
      className="
      google_link
      bg-[url('https://webnailsbucket.s3.amazonaws.com/pasch/Icon+Logo-04.svg')] 
      hover:animate-ping
      bg-cover bg-no-repeat p-2 w-10 h-10"
    ></a>
    </>
  )
}
export default SocialLink