"use client"

import { Popover, Transition } from "@headlessui/react"
import { ArrowRightMini, XMark } from "@medusajs/icons"
import { Region } from "@medusajs/medusa"
import { Text, clx, useToggleState } from "@medusajs/ui"
import { Fragment } from "react"
import Image from "next/image"

const Popup = () => {
  const toggleState = useToggleState()

  return (
    <div className="h-full">
      <div className="flex items-center h-full">
        <Popover className="h-full flex">
          {({ open = true, close }) => (
            <>
              <div className="relative flex h-full">
                <Popover.Button data-testid="nav-menu-button" className="relative h-full flex items-center transition-all ease-out duration-200 focus:outline-none hover:text-ui-fg-base">
                  Menu
                </Popover.Button>
              </div>

              <Transition
                show={open}
                as={Fragment}
                enter="transition ease-out duration-150"
                enterFrom="opacity-0"
                enterTo="opacity-100 backdrop-blur-2xl"
                leave="transition ease-in duration-150"
                leaveFrom="opacity-100 backdrop-blur-2xl"
                leaveTo="opacity-0"
              >
                <Popover.Panel className="flex flex-col absolute w-full p-4 sm:min-w-min h-[calc(100vh-1rem)] z-50 inset-x-0  backdrop-blur-2xl">
                  <div data-testid="nav-menu-popup" className="flex flex-col w-full h-full overflow-hidden bg-[rgba(62,93,171)] rounded-rounded items-center justify-between p-6">
                    <div className="flex content-end justify-end" id="xmark">
                      <button data-testid="close-menu-button" onClick={close}>
                        <XMark />
                      </button>
                    </div>
                    <div className="flex w-5/6 md:w-[600px] place-content-center">
                      <Image
                        src="https://webnailsbucket.s3.amazonaws.com/common/popup/4ofJuly-Rockstar.png"
                        alt="popup"
                        width={600} 
                        height={600} 
                        style={{
                          width: "auto",
                          height: "auto",
                        }}
                      />
                     
                    </div>
                    <div className="inline-flex w-[1400px] h-20 items-center justify-evenly">
                      <Image
                        className="w-1/2 h-20 items-center animate-moveXline1"
                        src="https://webnailsbucket.s3.amazonaws.com/common/popup/4ofJulytext-Rockstar.png"
                        alt="popup"
                        width={1400} 
                        height={19} 
                        style={{
                          width: "100%",
                          height: "auto",
                        }}
                      />
                    </div>
                    
                  </div>
                </Popover.Panel>
              </Transition>
            </>
          )}
        </Popover>
      </div>
    </div>
  )
}

export default Popup
